public class Actividad5 {
    public static void main(String[] args) {
        for (int i = 100; i >= 0; i--) {
            if (i%5 == 0 && i%7 == 0) {
                System.out.println(i);
            }
        }
    }
}
